---
layout: archive
title: "Recording my PhD"
permalink: /Recording my PhD/
author_profile: true
---


<span style="font-size: 14px; font-family: 'Arial', sans-serif; line-height: 0.7;">2020.Jan: start my PhD in Groningen</span><br>
