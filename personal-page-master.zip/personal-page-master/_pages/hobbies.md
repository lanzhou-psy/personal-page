---
permalink: /Hobbies/
title: "Art, Science and Faith"
author_profile: true
redirect_from: 
  - /hobbies/
  - /hobbies.html
---


### Gender equality
#### As females, we may encounter many adversities throughout our life. I am working on gender equality. I'm not sure if it can be considered a hobby, but I am dedicated to raising awareness among women that we should have the courage to construct our own identities, rather than being seen as objects under the power of men.

### Write fantasy novels
#### I am deeply interested in science fiction and fantasy fiction. I enjoy the process of melding my thoughts and beliefs into a story. I hope to write my own book, a successor to "Earth Sea."

### Painting
![Alt Text](/images/painting1.jpg)

### Traditional Chinese Medicine
#### I enjoy identifying different herbs and understanding how they work, based on the theories of traditional Chinese medicine. When hiking outside, I recognize various plants.

### Daoism 道 Philosophy
#### Zhuang Zi 庄子 is my favorite oriental philosopher. I benefit greatly from Daoism.
